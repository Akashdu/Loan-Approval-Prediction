# Loan-Approval-Prediction
A machine learning project as a part of college minor project. The prime objective of my project was to use machine learning and data analysis techniques to classify whether the loan of an applicant will be approved by the bank or not.
